<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <title>Job Hunter</title>
    <link rel="shortcut icon" src="favicon.ico">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    <!-- Font awesome icons -->
    <script src="https://kit.fontawesome.com/900b1285f7.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="/styles/custom.css">
</head>
<body>
    <header>
        <div class="collapse bg-dark" id="navbarHeader">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-md-7 py-4">
                        <h4 class="text-white">About</h4>
                        <p class="text-muted"><b class="text-success">Feeling confident you made the right choice, snatching up that fresh awesome talent- matters to you.</b> The same is true for the job hunt.
                            That's why <b>Job Hunter</b> makes it <i>so froggin' easy</i> to <a href="create.php"><b class="text-warning">hire your next awesome teammate,</b></a> <a href="index.php"><b class="text-warning">or apply to your next dream job,</b></a> for <b>FREE. Job Hunter will streamline your hiring process, starting now.</b></p>
                        </div>
                        <div class="col-sm-4 offset-md-1 py-4">
                            <h4 class="text-white">Contact</h4>
                            <ul class="list-unstyled">
                                <li><a target="_blank" rel="noopener noreferrer" href="https://greenlawtech.com" class="btn btn-success"><i class="fa fa-home" aria-hidden="true"></i> Back to Homepage</a></li>
                            </ul> 
                            <ul class="nav nav-pills">
                              <li class="nav-item">
                                <a class="nav-link active" href="create.php">HIRE</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">WORK</a>
                            </li>
                        </ul>
                    </div>        
                </div>
            </div>
        </div>
        <div class="navbar navbar-dark bg-dark box-shadow">
            <div class="container d-flex justify-content-between">
                <a href="index.php" class="navbar-brand d-flex align-items-center">
                    <img src="img/logo.png" width="317" height="60" class="mr-2" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </div>
    </header>
    <div class="container">
      <div class="header clearfix">
          <br><br>
          <!--<h1 class="text-center m-4"><?php echo SITE_TITLE; ?></h1>-->
      </div>
      <?php displayMessage(); ?>