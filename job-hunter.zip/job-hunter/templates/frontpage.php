<?php include 'inc/header.php'; ?>
<div class="shadow p-3 mb-2 bg-white rounded text-center">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h1>Hire For a Job</h1>
        <p class="p-2">Create a wanted ad here.</p>
        <a class="btn btn-success" href="create.php">Create Wanted Ads</a>
      </div>
      <div class="col-md-6">
        <h1>Find A Job</h1>
        <form method="GET" action="index.php">
          <div class="form-group"> 
            <select name="category" class="form-control">
              <option value="0">Search by Job Category</option> 
              <?php foreach($categories as $category): ?>
                <option value="<?php echo $category->id; ?>"><?php echo $category->name; ?></option>
              <?php endforeach; ?>
            </select>
            <br>
            <input type="submit" class="btn btn-success" value="Search Wanted Ads">
          </div>
        </form>
      </div>
    </div>
  </div>
</div>


<div class="album py-5 bg-light">
  <div class="container">
   <h3 class="text-center text-secondary"><u><?php echo $title; ?></u></h3>
   <?php foreach($jobs as $job): ?>
     <div class="row">
       <div class="col-md-12">
         <!-- Card -->
         <div class="card shadow p-3 mb-5 bg-white rounded">
           <h2 class="ml-3 text-success"><?php echo $job->job_title; ?></h2>
           <div class="card-body">
            <h5 class="card-text"><?php echo $job->description; ?></h5>
            <div class="d-flex justify-content-between align-items-center">
              <a class="btn btn-success" href="job.php?id=<?php echo $job->id; ?>"><i class="fa fa-list" aria-hidden="true"></i> See Details</a>
              <small class="text-muted">Post Date: <?php echo $job->post_date; ?></small>
            </div>
          </div>
        </div>
        <!-- Card -->
      </div>
    </div>  
  <?php endforeach; ?>    
</div>
</div>

<?php include 'inc/footer.php'; ?>