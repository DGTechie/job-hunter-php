# PHP & mPDF Job Board for Hiring or Working

> Similarly to Craigslist jobs, at Job Hunter.com you are free to post a job, or look for a new job..

## Quick Start

# Install dependencies
composer install

# Import jobhunter.sql into your DB

# Add your DB params in config/config.php

# Visit server location and create a FREE job posting or view others posts 

# Create a free job posting or view ones left by others who are hiring- sending them an email if you want to get hired, just like on Craigslist!

```

## App Info

### Author

Devon Greenlaw
[Greenlaw Tech](http://www.greenlawtech.com)

### Version

1.0.0

### License

This project is licensed under the MIT License
